g++ -o madelung madelung.cpp
./madelung
python madelung_plot.py